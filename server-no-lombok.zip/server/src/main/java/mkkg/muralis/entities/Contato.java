package mkkg.muralis.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "contatos")
public class Contato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "con_id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "con_cli_id", referencedColumnName = "cli_id", nullable = false)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "con_tpc_id", referencedColumnName = "tpc_id", nullable = false)
    private TipoContato tipo;

    @Column(name = "con_valor", length = 100, nullable = false)
    private String valor;

    @Column(name = "con_observacao")
    private String observacao;

    public Contato(Cliente cliente, TipoContato tipo, String valor, String observacao) {
        this.cliente = cliente;
        this.tipo = tipo;
        this.valor = valor;
        this.observacao = observacao;
    }

    public Contato() {
    }

    public Contato(Integer id, Cliente cliente, TipoContato tipo, String valor, String observacao) {
        this.id = id;
        this.cliente = cliente;
        this.tipo = tipo;
        this.valor = valor;
        this.observacao = observacao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public TipoContato getTipo() {
        return tipo;
    }

    public void setTipo(TipoContato tipo) {
        this.tipo = tipo;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
