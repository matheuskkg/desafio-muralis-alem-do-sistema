package mkkg.muralis.entities;

import jakarta.persistence.*;

@Entity
@Table(
        name = "tipos_contatos",
        uniqueConstraints = @UniqueConstraint(columnNames = {"tpc_tipo"})
)
public class TipoContato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tpc_id")
    private Integer id;

    @Column(name = "tpc_tipo", length = 50, nullable = false)
    private String tipo;

    public TipoContato() {
    }

    public TipoContato(Integer id, String tipo) {
        this.id = id;
        this.tipo = tipo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
