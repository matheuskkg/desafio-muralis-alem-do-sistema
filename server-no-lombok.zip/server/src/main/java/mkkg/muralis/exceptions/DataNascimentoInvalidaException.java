package mkkg.muralis.exceptions;

public class DataNascimentoInvalidaException extends RuntimeException {
    public DataNascimentoInvalidaException(String message) {
        super(message);
    }
}
