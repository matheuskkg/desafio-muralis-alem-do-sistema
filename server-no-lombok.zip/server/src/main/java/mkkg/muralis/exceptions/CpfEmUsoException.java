package mkkg.muralis.exceptions;

public class CpfEmUsoException extends RuntimeException {
    public CpfEmUsoException(String message) {
        super(message);
    }
}
