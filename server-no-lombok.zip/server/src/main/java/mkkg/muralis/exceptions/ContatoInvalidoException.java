package mkkg.muralis.exceptions;

public class ContatoInvalidoException extends RuntimeException {
    public ContatoInvalidoException(String message) {
        super(message);
    }
}
