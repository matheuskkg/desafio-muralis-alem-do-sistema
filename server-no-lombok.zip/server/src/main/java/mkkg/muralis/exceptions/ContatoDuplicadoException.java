package mkkg.muralis.exceptions;

public class ContatoDuplicadoException extends RuntimeException {
    public ContatoDuplicadoException(String message) {
        super(message);
    }
}
